from django.contrib import admin
from .models import FoodCategoryModel, FoodItemModel, CustRegModel

admin.site.register(FoodCategoryModel)
admin.site.register(FoodItemModel)
admin.site.register(CustRegModel)

