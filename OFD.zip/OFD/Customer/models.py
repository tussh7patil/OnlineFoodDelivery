from django.db import models

class FoodCategoryModel(models.Model):
    category_id = models.AutoField(primary_key=True)
    category_name = models.CharField(max_length=100, unique=True, null=False)

    def __str__(self):
        return self.category_name

class FoodItemModel(models.Model):
    item_id = models.AutoField(primary_key=True)
    item_name = models.CharField(max_length=100, unique=True, null=False)
    item_price = models.IntegerField(null=False)
    # item_photo = models.ImageField(upload_to='item/')
    item_status = models.BooleanField(null=False)
    item_category = models.CharField(max_length=100)

    def __str__(self):
        return self.item_name

class CustRegModel(models.Model):
    cust_id = models.AutoField(primary_key=True)
    cust_name = models.CharField(max_length=100)
    cust_contact = models.IntegerField(unique=True)
    cust_email = models.EmailField(unique=True)
    cust_address = models.CharField(max_length=100)
    cust_password = models.CharField(max_length=30)

# class CustLoginModel(models.Model):
#     cust_email = models.EmailField(unique=True)
#     cust_password = models.CharField(max_length=30)